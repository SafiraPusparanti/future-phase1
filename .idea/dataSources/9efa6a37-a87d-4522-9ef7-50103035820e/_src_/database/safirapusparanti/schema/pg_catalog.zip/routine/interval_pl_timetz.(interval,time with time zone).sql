create function interval_pl_timetz(interval, time with time zone) returns time with time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
